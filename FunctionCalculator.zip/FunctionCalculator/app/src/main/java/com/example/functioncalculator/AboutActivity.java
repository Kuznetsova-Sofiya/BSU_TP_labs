package com.example.functioncalculator;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView textViewAbout = findViewById(R.id.textViewAbout);
        Button btnBack = findViewById(R.id.btnBackFromAbout);

        // Анимация появления текста
        Animation fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        textViewAbout.startAnimation(fadeIn);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}