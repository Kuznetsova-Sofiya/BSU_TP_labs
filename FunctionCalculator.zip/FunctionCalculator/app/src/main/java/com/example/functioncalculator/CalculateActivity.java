package com.example.functioncalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CalculateActivity extends AppCompatActivity {

    private EditText editTextA, editTextX;
    private RadioButton radioRadians;
    private CheckBox checkBoxRound;
    private Spinner spinnerPrecision;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);

        // Инициализация всех элементов
        editTextA = findViewById(R.id.editTextA);
        editTextX = findViewById(R.id.editTextX);
        radioRadians = findViewById(R.id.radioRadians);
        checkBoxRound = findViewById(R.id.checkBoxRound);
        spinnerPrecision = findViewById(R.id.spinnerPrecision);
        textViewResult = findViewById(R.id.textViewResult);

        Button btnCalculate = findViewById(R.id.btnCalculateFunction);
        Button btnBack = findViewById(R.id.btnBack);

        // Настройка Spinner для выбора точности
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.precision_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPrecision.setAdapter(adapter);

        // Обработчик кнопки "Вычислить"
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateFunction();
            }
        });

        // Обработчик кнопки "Назад"
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Закрываем текущую Activity
            }
        });
    }

    // Метод для вычисления функции y = a / x * sin(x)
    private void calculateFunction() {
        try {
            // Получаем значения из полей ввода
            String aStr = editTextA.getText().toString();
            String xStr = editTextX.getText().toString();

            // Проверка на пустые поля
            if (aStr.isEmpty() || xStr.isEmpty()) {
                textViewResult.setText("Ошибка: Введите значения a и x!");
                return;
            }

            // Преобразуем строки в числа
            double a = Double.parseDouble(aStr);
            double x = Double.parseDouble(xStr);

            // Проверка: x должен быть положительным
            if (x <= 0) {
                textViewResult.setText("Ошибка: x должен быть положительным числом!");
                return;
            }

            // Преобразование градусов в радианы, если выбраны градусы
            if (!radioRadians.isChecked()) {
                x = Math.toRadians(x);
            }

            // Проверка деления на ноль (после преобразования)
            if (x == 0) {
                textViewResult.setText("Ошибка: деление на ноль!");
                return;
            }

            // ВЫЧИСЛЕНИЕ ФУНКЦИИ: y = a / x * sin(x)
            double result = a / x * Math.sin(x);

            // Округление результата, если выбрана опция
            if (checkBoxRound.isChecked()) {
                int precision = Integer.parseInt(spinnerPrecision.getSelectedItem().toString());
                double scale = Math.pow(10, precision);
                result = Math.round(result * scale) / scale;
            }

            // Вывод результата
            // textViewResult.setText(String.format("Результат: y = %.6f", result));
             textViewResult.setText(String.format("Результат: y = %.6f", result));

        } catch (NumberFormatException e) {
            // Ошибка при преобразовании строки в число
            textViewResult.setText("Ошибка: введите корректные числа!");
        } catch (ArithmeticException e) {
            // Математическая ошибка
            textViewResult.setText("Ошибка вычисления: " + e.getMessage());
        } catch (Exception e) {
            // Любая другая ошибка
            textViewResult.setText("Ошибка: " + e.getMessage());
        }
    }

    // Дополнительный метод для демонстрации работы (можно удалить)
    private void showExample() {
        // Пример вычисления для демонстрации
        editTextA.setText("2.5");
        editTextX.setText("3.14");

        // Автоматический расчет
        calculateFunction();
    }
}